# Get count of base table records;
# nohup ct_base.sh &

# Get Distinct tables in the Custom Log Table
nohup dist_conv_log_tables.sh &

# Get pending batches
nohup pending.sh &

# Get all distinct errors in Bulk and Custom - No batch-ids
nohup all_errors.sh &

# Get Bulk Import Errors - With Batch_Id
nohup bulk_imp_errors.sh &

# Get Errors in Custom Tables - With Batch_Id
nohup dist_conv_log_tables.sh &
nohup dist_as.sh &
nohup dist_asu.sh &
nohup dist_bank.sh &
nohup dist_ct.sh &
nohup dist_ctpt.sh &
nohup dist_ctrls.sh &
nohup dist_ext.sh &
nohup dist_relships.sh &
nohup dist_actprf.sh &
nohup dist_a.sh &
nohup dist_pay.sh &


# Change permissions for all so I can delete files if needed
chmod  777 logs/*
