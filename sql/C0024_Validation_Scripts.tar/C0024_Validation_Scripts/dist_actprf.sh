rm logs/dist_ext.log
sqlplus apps_ro/apps_ro<<EOF
set timing on
set time on
spool logs/dist_actprf.log
set pages 20000
set lines 132
column aops format 9999999
column ebs format 9999999
column error format a80
column Ct format 9999999
column org_id format 99999
select a.aops_batch_id AOPS, e.batch_id EBS, s.org_id, e.exception_log error, count(1) Ct
from apps.XX_COM_EXCEPTIONS_LOG_CONV e
, apps.XXOD_HZ_IMP_ACCOUNT_PROF_STG s
, apps.XX_OWB_CRMBATCH_STATUS a
where a.ebs_batch_id = e.batch_id
and s.record_id = e.record_control_id
and s.INTERFACE_STATUS = 6
and e.exception_id = (select max(exception_id) from xxcomn.XX_COM_EXCEPTIONS_LOG_CONV ilog
                      where ilog.batch_id = e.batch_id
                      and ilog.record_control_id = e.record_control_id
                      and ilog.STAGING_TABLE_NAME = 'XXOD_HZ_IMP_ACCOUNT_PROF_STG')
group by a.aops_batch_id, e.batch_id, s.org_id, e.exception_log
order by 1, 2, 3;
EOF
