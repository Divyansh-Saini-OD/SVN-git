sqlplus apps_ro/apps_ro<<EOF
set time on
set timing on
spool logs/missing_billto_2.log
select /*+ parallel (hca, 4) */
hca.orig_system_reference 
from apps.hz_cust_accounts hca
where orig_system_reference like '%A0'
and not exists (
select  1
from apps.hz_cust_acct_sites_all hcas
where 
hcas.orig_system_reference = hca.orig_system_reference);
EOF
