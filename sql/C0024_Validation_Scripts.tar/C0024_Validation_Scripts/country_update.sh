sqlplus apps_ro/apps_ro<<EOF
set time on
set timing on
set lines 240
set pages 50000
spool logs/country_update.sql
select 'update hz_locations set country = '''||l.country||'''where location_id = (select location_id from hz_party_sites where orig_system_reference = '''||ps.orig_system_reference||''');'
from apps.hz_locations l, apps.hz_party_sites ps
where ps.location_id = l.location_id
and l.country not in ('US', 'CA')
and ps.orig_system_reference like '%A0';
EOF
