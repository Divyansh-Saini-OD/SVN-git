rm logs/aops_notloaded_a_refs.log
sqlplus apps_ro/apps_ro<<EOF
set time on
set timing on
set pages 50000
set lines 132
column AOPS_ACCOUNT_REFERENCE format a50
column ENTITY format a35
spool logs/notloaded_a_refs.log
select distinct * from 
(select 'AOPS_ACCOUNT' ENTITY, account_orig_system_reference AOPS_ACCOUNT_REFERENCE from apps.XXOD_HZ_IMP_ACCOUNTS_STG where account_orig_system = 'A0' and batch_id in (select ebs_batch_id from apps.XX_OWB_CRMBATCH_STATUS)
minus
select 'AOPS_ACCOUNT' ENTITY, orig_system_reference AOPS_ACCOUNT_REFERENCE from apps.hz_orig_sys_references where owner_table_name = 'HZ_CUST_ACCOUNTS' and orig_system = 'A0')
order by 2;
EOF
