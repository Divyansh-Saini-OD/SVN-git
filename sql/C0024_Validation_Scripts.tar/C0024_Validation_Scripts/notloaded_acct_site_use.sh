rm logs/aops_notloaded_asu_refs.log
sqlplus apps_ro/apps_ro<<EOF
set time on
set timing on
set pages 50000
set lines 132
column AOPS_REFERENCE format a50
column ENTITY format a35
spool logs/notloaded_asu_refs.log
select * from 
(select 'AOPS_ACCOUNT_SITE_USE' ENTITY, ACCT_SITE_ORIG_SYS_REFERENCE||'-'||SITE_USE_CODE AOPS_REFERENCE from apps.XXOD_HZ_IMP_ACCT_SITE_USES_STG where account_orig_system = 'A0' and batch_id in (select ebs_batch_id from apps.XX_OWB_CRMBATCH_STATUS)
minus
select 'AOPS_ACCOUNT_SITE_USE' ENTITY, orig_system_reference AOPS_REFERENCE from apps.hz_orig_sys_references where owner_table_name = 'HZ_CUST_SITE_USES_ALL' and orig_system = 'A0')
order by 2;
EOF
