rm logs/aops_notloaded_as_refs.log
sqlplus apps_ro/apps_ro<<EOF
set time on
set timing on
set pages 50000
set lines 132
column AOPS_REFERENCE format a50
column ENTITY format a35
spool logs/notloaded_as_refs.log
select distinct * from (select 'AOPS_ACCOUNT_SITE' ENTITY, ACCT_SITE_ORIG_SYS_REFERENCE AOPS_REFERENCE from apps.XXOD_HZ_IMP_ACCT_SITES_STG where account_orig_system = 'A0' and batch_id in (select ebs_batch_id from apps.XX_OWB_CRMBATCH_STATUS)
minus
select 'AOPS_ACCOUNT_SITE' ENTITY, orig_system_reference AOPS_REFERENCE from apps.hz_orig_sys_references where owner_table_name = 'HZ_CUST_ACCT_SITES_ALL' and orig_system = 'A0') order by 2;
EOF
