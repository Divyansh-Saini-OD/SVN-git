rm logs/dist_tables.log
sqlplus apps_ro/apps_ro<<EOF
set timing on
set time on
spool logs/dist_tables.log
set pages 20000
select distinct STAGING_TABLE_NAME 
from apps.XX_COM_EXCEPTIONS_LOG_CONV
where BATCH_ID  in (select EBS_BATCH_ID 
                    from apps.XX_OWB_CRMBATCH_STATUS);
EOF
