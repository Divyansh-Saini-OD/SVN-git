rm logs/bulk_imp_errors.out;

sqlplus apps_ro/apps_ro<<EOF
set timing on
set time on
set linesize 132;
set pages 10000;
column aops format 9999;
column EBS format 99999;
column entity a30;
column message_name format a30;
column token1_name format a20;
column token1_value format a20;
column ct format 9999999;
spool logs/bulk_imp_errors.out;
select b.aops_batch_id aops,
       a.batch_id ebs,
       a.interface_table_name entity , 
       a.message_name,
       a.token1_name,
       a.token1_value,
       count(*) ct
from   hz_imp_errors a,
       apps.xx_owb_crmbatch_status b
where  a.batch_id = b.ebs_batch_id
and    b.aops_batch_id > 1000
group by b.aops_batch_id, a.batch_id,a.interface_table_name, a.message_name,a.token1_name, a.token1_value
order by b.aops_batch_id;
EOF
