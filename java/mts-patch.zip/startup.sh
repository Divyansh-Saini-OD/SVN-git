#!/bin/ksh
export MTS_HOME=/app/orclas/mts/MTServer

java -classpath /app/orclas/mts/MTServer/classes:/app/orclas/mts/MTServer/lib/activation.jar:/app/orclas/mts/MTServer/lib/ejb.jar:/app/orclas/mts/MTServer/lib/ejbtest-bean.jar:/app/orclas/mts/MTServer/lib/jaxb1-impl.jar:/app/orclas/mts/MTServer/lib/jaxb-api.jar:/app/orclas/mts/MTServer/lib/jaxb-impl.jar:/app/orclas/mts/MTServer/lib/jxb-xjc.jar:/app/orclas/mts/MTServer/lib/jsr173_1.0_api.jar:/app/orclas/mts/MTServer/lib/log4j-1.2.jar:/app/orclas/mts/MTServer/lib/oc4j.jar:/app/orclas/mts/MTServer/lib/orcl-mts.jar:/app/orclas/mts/MTServer/lib/oc4jclient.jar:/app/orclas/mts/MTServer/lib/optic.jar:.: od.otc.mts.MTServer $MTS_HOME
