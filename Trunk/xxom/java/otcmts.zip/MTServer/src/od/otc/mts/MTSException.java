package od.otc.mts;

/**
 * <p>Exception class for the MTServer. Whenever an exception 
 * occurs object of this class is thrown.
 */
public class MTSException extends Exception {

    private String sErrDesc = "";
    private int iErrNumber = -1;
    private Exception oCause = null;

    /**
     * <p>Default constructor
     * 
     * @param sErrDesc - Error Description
     */
    public MTSException(String sErrDesc) {
        super(sErrDesc);
        this.sErrDesc = sErrDesc;
    }

    public MTSException(String sErrDesc, int iErrNumber) {
        super(sErrDesc);
        this.sErrDesc = sErrDesc;
        this.iErrNumber = iErrNumber;
    }

    public MTSException(String sErrDesc, int iErrNumber, Throwable oThrow) {
        super(sErrDesc,oThrow); 
        this.sErrDesc = sErrDesc;
        this.iErrNumber = iErrNumber;
        oCause = (Exception)oThrow;
    }

    /**
     * <p>Returns the error description
     * 
     * @return String - Error description
     */
    public String getErrorDescription() {
        return sErrDesc;
    }

    /**
     * <p>Returns the error number
     * 
     * @return int - Error number
     */
    public int getErrorNumber() {
        return iErrNumber;
    }

    /**
     * <p>Returns the Exception
     * 
     * @return Exception - Cause of the error
     */
    public Throwable getExceptionCause() {
        return oCause;
    }

}
