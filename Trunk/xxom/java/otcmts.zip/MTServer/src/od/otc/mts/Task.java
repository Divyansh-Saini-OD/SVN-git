package od.otc.mts;

public interface Task {

   public void execute();
   public void setReturnObject(Object obj);
   public Object getReturnObject();
    
}
