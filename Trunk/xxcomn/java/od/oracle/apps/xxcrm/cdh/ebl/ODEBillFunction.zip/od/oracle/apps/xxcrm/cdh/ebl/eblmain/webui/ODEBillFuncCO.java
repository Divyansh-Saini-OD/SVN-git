/*===========================================================================+
 |   Copyright (c) 2001, 2003 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package od.oracle.apps.xxcrm.cdh.ebl.eblmain.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import java.sql.SQLException;
import java.sql.ResultSet;
import oracle.jdbc.OracleCallableStatement;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.OARow;
import oracle.jbo.domain.Number;

//import oracle.jbo.domain.Date;
//import java.sql.Types;

/**
 * Controller for ...
 */
public class ODEBillFuncCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    //OAMessageStyledTextBean InstructionBean = (OAMessageStyledTextBean)webBean.findChildRecursive("InstructionBean");
    OAMessageTextInputBean qryTxt=(OAMessageTextInputBean)webBean.findChildRecursive("QryInputItm");
    //InstructionBean.setText(pageContext,"Enter Query Without Semicolan. Query can have Functions or Columns");
    String funTxt = pageContext.getParameter("Function");
    /*if(qryTxt.getText(pageContext)==null)
      qryTxt.setText(funTxt);
    */
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    String QrySel = "Select ";
    Number nFldId;
    String FrmClause = " From Dual";
    //Getting Column Name from ID passed
    String colName = pageContext.getParameter("Column1");
    if (colName!=null)
    {
      OAViewObject fieldsVO = (OAViewObject)am.findViewObject("ODEBillFieldsPVO");
      fieldsVO.executeQuery();
      pageContext.writeDiagnostics(this,"FieldsVO Row Count:"+fieldsVO.getRowCount(),5);
      try
      {
        nFldId = new Number(colName);
      }
      catch(SQLException e)
      {
        throw new OAException("Unexpected Error:"+e.toString(),OAException.ERROR);
      }
      OARow curRow=(OARow)fieldsVO.getFirstFilteredRow("FieldId",nFldId);
      if (curRow!=null) 
        colName=(String)curRow.getAttribute("FieldName");
    }
    
    String funTxt = "(" + colName + ")";

    if (pageContext.getParameter("Validate") != null)
    {
      OAMessageTextInputBean QryInputItm = (OAMessageTextInputBean)webBean.findChildRecursive("QryInputItm");
      String QryTxt = QrySel 
                      + QryInputItm.getText(pageContext)
                      + funTxt
                      + FrmClause;
      pageContext.putSessionValue("CplxFun",QryInputItm.getText(pageContext) + funTxt);
      pageContext.writeDiagnostics(this,"Query is :"+QryTxt,5);
      String resultTxt = validateQuery(QryTxt,pageContext,webBean);
      throw new OAException(resultTxt);
    }
    else if (pageContext.getParameter("Select") != null)
    {
      pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/cdh/ebl/eblmain/webui/ODEBillETxtFunctionPG",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      null, //null, //params
                                      true, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES);
    }
    
  }

  public String validateQuery(String strQuery,OAPageContext pageContext, OAWebBean webBean)
  {
    String resText="Query is Valid";
    try
    {
      OracleCallableStatement ocs = null;
      OAApplicationModule am=pageContext.getApplicationModule(webBean);
      OADBTransaction oadb=am.getOADBTransaction();
      ResultSet rs;
     
      //String stmt="BEGIN "+p_procedure+"; END;";
      String stmt=strQuery;
      try
      {
        ocs = (OracleCallableStatement)oadb.createCallableStatement(stmt, 1);
        rs = ocs.executeQuery(); 
        if(rs.next())
          resText = rs.getObject(1).toString();
      }
      catch(SQLException sqlexception)
      {
          throw sqlexception;
      }
      finally
      {
          if(ocs != null)
              ocs.close();
      }
    }
    catch(Exception e)
    {
      //throw new OAException(e.toString());
      return strQuery + " Err Msg:" + e.toString();
    }
    return "Success! "+strQuery+" Result: "+resText;
   }
}