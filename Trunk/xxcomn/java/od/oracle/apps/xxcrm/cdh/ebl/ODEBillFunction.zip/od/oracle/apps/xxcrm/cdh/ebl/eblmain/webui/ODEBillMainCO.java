package od.oracle.apps.xxcrm.cdh.ebl.eblmain.webui;
/*
  -- +===========================================================================+
  -- |                  Office Depot - eBilling Project                          |
  -- |                         WIPRO/Office Depot                                |
  -- +===========================================================================+
  -- | Name        :  ODEBillMainCO                                              |
  -- | Description :                                                             |
  -- | This is the controller for eBill Main Page                                |
  -- |                                                                           |
  -- |                                                                           |
  -- |                                                                           |
  -- |Change Record:                                                             |
  -- |===============                                                            |
  -- |Version  Date        Author               Remarks                          |
  -- |======== =========== ================     ================================ |
  -- |DRAFT 1A 15-JAN-2010 Devi Viswanathan     Initial draft version            |
  -- |                                                                           |
  -- |                                                                           |
  -- |                                                                           |
  -- |===========================================================================|
  -- | Subversion Info:                                                          |
  -- | $HeadURL: http://svn.na.odcorp.net/od/common/branches/10.4/xxcomn/java/od/oracle/apps/xxcrm/cdh/ebl/eblmain/webui/ODEBillMainCO.java $                                                               |
  -- | $Rev: 113643 $                                                                   |
  -- | $Date: 2010-09-14 00:18:12 +0530 (Tue, 14 Sep 2010) $                                                                  |
  -- |                                                                           |
  -- +===========================================================================+
*/

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.common.MessageToken;


import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import od.oracle.apps.xxcrm.cdh.ebl.server.ODUtil;
import oracle.apps.fnd.framework.webui.TransactionUnitHelper;
import java.io.Serializable;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.beans.layout.OASubTabLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAStackLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAMessageComponentLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAAttachmentTableBean;
import oracle.apps.fnd.framework.webui.beans.OAImageBean;


import com.sun.java.util.collections.HashMap;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import java.util.Hashtable;
import com.sun.java.util.collections.HashMap;
import oracle.jbo.domain.Number;
import oracle.jdbc.OracleCallableStatement;
import java.sql.ResultSet;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.jdbc.OracleResultSet;
import java.sql.SQLException;

/**
 * Controller for Cust Doc Main Page
 */

 
public class ODEBillMainCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {

    ODUtil utl = new ODUtil(pageContext.getApplicationModule(webBean));
    utl.log("Inside processRequest");   
 
    super.processRequest(pageContext, webBean);  
    
    String custAccountId = pageContext.getParameter("custAccountId");
    String custDocId = pageContext.getParameter("custDocId");
    String deliveryMethod = pageContext.getParameter("deliveryMethod");
    String isParent = null;
    String status = null;
    String directDoc = null;
    String transmissionType = null;    

    utl.log("In parameters: custAccountId " +  custAccountId); 
    utl.log("In parameters: custDocId " +  custDocId);  
    utl.log("In parameters: deliveryMethod " +  deliveryMethod); 

    OAApplicationModule mainAM = (OAApplicationModule) pageContext.getApplicationModule(webBean);
    utl.log("**AM Created:" + mainAM.getDefName());  

    //Fetching header details
    OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO"); 
    String docType = null;
    if (custDocVO != null)
    {
      custDocVO.setWhereClause(null);  
      custDocVO.setWhereClause("cust_account_id = '" + custAccountId + "' and cust_doc_id = " + custDocId  );      
      custDocVO.executeQuery();
    }
    
    if (custDocVO.getRowCount() > 0)
    {
      OARow custRow = (OARow) custDocVO.first();

      String custName = null;
      if ( custRow != null)
      {
        custName = (String) custRow.getAttribute("CustomerName");
        custAccountId = custRow.getAttribute("CustAccountId").toString();
        docType = custRow.getAttribute("DocType").toString();
        Object o = custRow.getAttribute("IsParent");
        status = custRow.getAttribute("StatusCode").toString(); 
        directDoc = custRow.getAttribute("DirectDoc").toString(); 
          
        if (o == null)
          isParent = "0";
        else 
          isParent = o.toString();
      }
     
    }

    /* Disabling and enabling subTabs */   
    if (deliveryMethod.equals("ePDF"))
    {
      utl.log("Inside PF Disabling enabling when deliveryMethod = ePDF");          
      OAStackLayoutBean configDetailsRN = (OAStackLayoutBean) webBean.findIndexedChildRecursive("ConfigurationDetailsRN");               
      configDetailsRN.removeIndexedChild(1);                 
      configDetailsRN.removeIndexedChild(0); 
      OAStackLayoutBean subTotalRN = (OAStackLayoutBean) webBean.findIndexedChildRecursive("SubTotalRN");                 
      subTotalRN.removeIndexedChild(0);
      OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
      subTabsBean.hideSubTab(3, true); 
      subTabsBean.hideSubTab(4, true);     
      subTabsBean.hideSubTab(5, true);  
      OAMessageChoiceBean fileProcessMtd = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("FileProcessingMethod");
      fileProcessMtd.setDisabled(false);  
      OAMessageChoiceBean logoFileName = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("LogoFileName");
      logoFileName.setDisabled(true); 
      OAMessageCheckBoxBean includeHeader = (OAMessageCheckBoxBean) webBean.findIndexedChildRecursive("IncludeHeader");
      includeHeader.setDisabled(true);        
      OAMessageChoiceBean stdContLvl = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("StdContLvl");
      stdContLvl.setDisabled(true);    
      OAMessageChoiceBean fileCreationType = (OAMessageChoiceBean) webBean.findChildRecursive("FileCreationType");
      fileCreationType.setDisabled(true);       
    }
    if (deliveryMethod.equals("eTXT"))  
    {
      utl.log("Inside PF Disabling enabling when deliveryMethod = eTXT");             
      OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
      subTabsBean.hideSubTab(5, true);
      OAStackLayoutBean configDetailsRN = (OAStackLayoutBean) webBean.findIndexedChildRecursive("ConfigurationDetailsRN");
      configDetailsRN.removeIndexedChild(0);   
      OAStackLayoutBean subTotalRN = (OAStackLayoutBean) webBean.findIndexedChildRecursive("SubTotalRN");                 
      subTotalRN.removeIndexedChild(0);                
      OAMessageChoiceBean fileCreationType = (OAMessageChoiceBean) webBean.findChildRecursive("FileCreationType");
      fileCreationType.setRequired("true");
      OAMessageChoiceBean logoFileName = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("LogoFileName");
      logoFileName.setDisabled(true); 
     // OAMessageCheckBoxBean includeHeader = (OAMessageCheckBoxBean) webBean.findIndexedChildRecursive("IncludeHeader");
     // includeHeader.setDisabled(true);        
      OAMessageChoiceBean stdContLvl = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("StdContLvl");
      stdContLvl.setDisabled(true);  
    }
    if (deliveryMethod.equals("eXLS") || deliveryMethod.equals("eTXT") )
    {
      if (isParent.equals("1"))
      {
        OAMessageChoiceBean splitType = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("SplitType");
        splitType.setDisabled(true);  
        OAMessageTextInputBean splitValue = (OAMessageTextInputBean) webBean.findIndexedChildRecursive("SplitValue");
        splitType.setDisabled(true);          
      }             
    } 
    if (deliveryMethod.equals("eXLS"))
    {   
      utl.log("Inside PF Disabling enabling when deliveryMethod = eXLS");
      OAStackLayoutBean configDetailsRN = (OAStackLayoutBean) webBean.findIndexedChildRecursive("ConfigurationDetailsRN");
      configDetailsRN.removeIndexedChild(1); 
      OAMessageChoiceBean fileCreationType = (OAMessageChoiceBean) webBean.findChildRecursive("FileCreationType");
      fileCreationType.setDisabled(true);  
      OAMessageChoiceBean lineFeedStyle = (OAMessageChoiceBean) webBean.findChildRecursive("LineFeed");
      lineFeedStyle.setDisabled(true);  
    }

    //Display contact tab only if transmission type is "EMAIL" 

    OAViewObject mainVO = (OAViewObject) mainAM.findViewObject("ODEBillMainVO"); 
    OARow mainRow = null;
    if ( mainVO != null)
      mainRow = (OARow) mainVO.first();
    if (mainRow != null)
      transmissionType = (String) mainRow.getAttribute("EbillTransmissionType");
      
    if (transmissionType == null || "EMAIL".equals(transmissionType))
    {
      OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
      subTabsBean.hideSubTab(1, false);  
      OAImageBean updateContactBean = (OAImageBean) webBean.findChildRecursive("UpdateContact");
      updateContactBean.setAttributeValue(OAWebBeanConstants.TARGET_FRAME_ATTR, "_blank");
      
    }      
    else 
    {
      OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
      subTabsBean.hideSubTab(1, true);  
    }     
   
    if("COMPLETE".equals(status))
    {
      utl.log("**********Inside Complete Status************");          
      OAMessageChoiceBean stdContLvl = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("StdContLvl");
      stdContLvl.setDisabled(true);    
      OAMessageChoiceBean fileProcessMtd = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("FileProcessingMethod");
      fileProcessMtd.setDisabled(true); 
      OAMessageChoiceBean fileCreationType = (OAMessageChoiceBean) webBean.findChildRecursive("FileCreationType");
      fileCreationType.setDisabled(true);      
    }   
    /* *** To handle PPRs when the users navigate to the tab region to avoid page refresh and stale data *** */
    if ("update".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
      return; 
      
     // Back Button code 
     if (!pageContext.isBackNavigationFired(false))
     {
       // We indicate that we are starting the create transaction (this 
       // is used to ensure correct Back button behavior).

       TransactionUnitHelper.startTransactionUnit(pageContext, "MainTxn");

       if (!pageContext.isFormSubmission())
       { 

           // Initializing the View Objects and defaulting values
           String emailSubj = null;
           if (docType.equals("Invoice"))
             emailSubj = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SUB_STAND");
           else
             emailSubj = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SUB_CONSOLI"); 
           
           String emailStdMsg = pageContext.getProfile("XXOD_EBL_EMAIL_STD_MSG");
           String emailSign = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SIGN");
           String emailStdDisc = pageContext.getProfile("XXOD_EBL_EMAIL_STD_DISCLAIM");  
           emailStdDisc = emailStdDisc + pageContext.getProfile("XXOD_EBL_EMAIL_STD_DISCLAIM1");
           String emailSplInst = pageContext.getProfile("XXOD_EBL_EMAIL_SPL_INSTRUCT");

           String ftpEmailSubj = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_SUBJ");
           String ftpEmailCont = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_CONT");
           String ftpNotiFileTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_FILE_TEXT");  
           String ftpNotiEmailTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT");  
           ftpNotiEmailTxt = ftpNotiEmailTxt + pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT1");           
           String logoFile = pageContext.getProfile("XXOD_EBL_LOGO_FILE");  
           String associateName = pageContext.getProfile("XXOD_EBL_ASSOCIATE_NAME");  
       
           Serializable initializeParams[] = { custDocId, custAccountId, deliveryMethod, directDoc
                                             , emailSubj, emailStdMsg, emailSign, emailStdDisc, emailSplInst
                                             , ftpEmailSubj, ftpEmailCont, ftpNotiFileTxt, ftpNotiEmailTxt
                                             , logoFile, associateName  }; 

           utl.log("**Inside Main controller Email :emailSubj" + emailSubj + ":emailStdMsg:" + emailStdMsg + ":emailSign:" + emailSign + ":emailStdDisc:" + emailStdDisc + ":emailSplInst:" + emailSplInst ); 
         
           String newFlag = (String) mainAM.invokeMethod("initializeMain", initializeParams);
   
           //Iniitalize the ApplicationPropertiesVO for PPR.
           Serializable initPPRParams[] = { status};           
           mainAM.invokeMethod("initPPRVO", initPPRParams);

         
           // PPR hanlding
           transmissionType = (String) mainAM.invokeMethod("handleTransPPR" );        
           mainAM.invokeMethod("handleCompressPPR" ); 
           mainAM.invokeMethod("handleLogoReqPPR" ); 
           Serializable[] notifyParam = { ftpEmailSubj, ftpEmailCont };           
           mainAM.invokeMethod("handleNotifyCustPPR", notifyParam ); 
           Serializable[] sendZeroParam = { ftpNotiFileTxt, ftpNotiEmailTxt };           
           mainAM.invokeMethod("handleSendZeroPPR", sendZeroParam ); 

           //Display contact tab only if transmission type is "EMAIL"   
           if (transmissionType == null || "EMAIL".equals(transmissionType)  )
           {
             OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
             subTabsBean.hideSubTab(1, false);  
             OAImageBean updateContactBean = (OAImageBean) webBean.findChildRecursive("UpdateContact");
             updateContactBean.setAttributeValue(OAWebBeanConstants.TARGET_FRAME_ATTR, "_blank");             
           }      
           else 
           {
             OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
             subTabsBean.hideSubTab(1, true);  
           }            
           

           //Deleting existing error details
           Serializable deleteParams[] = { custDocId };           
           mainAM.invokeMethod("deleteErrorCodes", deleteParams);

          if ("eXLS".equals(deliveryMethod))
          { 
            OAViewObject templDtlVO = (OAViewObject) mainAM.findViewObject("ODEBillTemplDtlVO");
            templDtlVO.setWhereClause(null);  
            templDtlVO.setWhereClause("cust_doc_id = " + custDocId );      
            templDtlVO.executeQuery(); 
            Serializable templParams[] = {custDocId};  
            mainAM.invokeMethod("populateTemplDtl", templParams);   
           // String stdCont = (String) mainAM.invokeMethod("populateTemplDtl", templParams);   
           // pageContext.putSessionValue("stdContVar", stdCont);
          } 
          if ("eTXT".equals(deliveryMethod) || "eXLS".equals(deliveryMethod))
          {
            mainAM.invokeMethod("handleDelimitedPPR" );           
            Serializable configParams[] = { deliveryMethod, status };           
            mainAM.invokeMethod("handleconfigPPR", configParams); 
          }          
          if ("eTXT".equals(deliveryMethod))  
          {
            mainAM.invokeMethod("handleDelimitedPPR" );         
          }  
          utl.log("&&&&&&&&&&Before Complete Status************: " +  status);    
          if("COMPLETE".equals(status))
          {
            utl.log("**********Inside Complete Status************");          
            OAMessageChoiceBean stdContLvl = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("StdContLvl");
            stdContLvl.setDisabled(true);  
            OAMessageChoiceBean fileProcessMtd = (OAMessageChoiceBean) webBean.findIndexedChildRecursive("FileProcessingMethod");
            fileProcessMtd.setDisabled(true);   
            OAMessageChoiceBean fileCreationType = (OAMessageChoiceBean) webBean.findChildRecursive("FileCreationType");
            fileCreationType.setDisabled(true);            
          }
        }
      }
      else 
      { 
        if (!TransactionUnitHelper.isTransactionUnitInProgress(pageContext, "MainTxn",    true))
        { 
            
          OADialogPage dialogPage = new OADialogPage(NAVIGATION_ERROR); 
          pageContext.redirectToDialogPage(dialogPage); 
        } 
      } 
    if ("Save".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM))) 
    {
      utl.log("Inside PF under save button handle"); 
      MessageToken[] tokens = null;
      OAException confirmMessage = new OAException("XXCRM","XXOD_EBL_SAVE_SUCCESS",null, OAException.INFORMATION,null);       
      pageContext.putDialogMessage(confirmMessage);
    }

   if ("ChangeStatus".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PR ChangeStatus Event:");  
      //When validations are successful      
      String returnStatus = pageContext.getParameter("changeStatus");
      if (returnStatus.equals("Success"))
      { 
        utl.log("**Inside PFR ChangeStatus Event: validationFinal Validate Final Success: returnStatus:" + returnStatus);             
        OAException confirmMessage = new OAException("XXCRM","XXOD_EBL_CHANGE_STATUS_SUCCESS",null, OAException.INFORMATION,null);     
        pageContext.putDialogMessage(confirmMessage); 
      }
      else
      { 
        utl.log("**Inside PFR ChangeStatus Event: Validate Final failed: returnStatus:" + returnStatus);        
        OAException confirmMessage = new OAException("XXCRM","XXOD_EBL_CHANGE_STATUS_FAILED");     
        pageContext.putDialogMessage(confirmMessage); 
      }    

    } 

    
   } //processRequest

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    ODUtil utl = new ODUtil(pageContext.getApplicationModule(webBean));

    utl.log("Inside processFormRequest: " + pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM) );        

    OAApplicationModule mainAM = pageContext.getApplicationModule(webBean);
    /* Handle for save button to save customer doc details */
    if ("Save".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM))) 
    {
       utl.log("Inside Save"); 
       OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO");             
       String deliveryMethod = custDocVO.first().getAttribute("DeliveryMethod").toString(); 
      
       Serializable[] applyMainPara = { deliveryMethod };         
       mainAM.invokeMethod("applyMain", applyMainPara);    // Indicate that the Create transaction is complete.

       TransactionUnitHelper.endTransactionUnit(pageContext, "MainTxn");           
       pageContext.forwardImmediatelyToCurrentPage(null,false,OAWebBeanConstants.ADD_BREAD_CRUMB_YES);

    
     }
    /* Handle for cancel button*/ 
     if ("Cancel".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)) )
     {
       utl.log("Inside Cancel");       
       mainAM.invokeMethod("rollbackMain");       // Indicate that the Create transaction is complete.
       TransactionUnitHelper.endTransactionUnit(pageContext, "MainTxn");  
       pageContext.forwardImmediatelyToCurrentPage(null,false,OAWebBeanConstants.ADD_BREAD_CRUMB_YES);       
     } //else if Cancel
     /*Handle for transmission PPR event. */
     if ("updateTransmissionType".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
     {
      OAException mainMessage = new OAException("Current transmission details will be lost if the transmission type is changed. Do you wish to continue?" );

      OADialogPage dialogPage = new OADialogPage(OAException.WARNING, mainMessage, null, "", "");

      String transmissionType = pageContext.getParameter("transmissionType");
      utl.log("Inside updateTransmissionType:transmissionType:" + transmissionType);      

      dialogPage.setOkButtonItemName("UpdateTransYesButton");
      dialogPage.setNoButtonItemName("UpdateTransNoButton");

      dialogPage.setOkButtonToPost(true);
      dialogPage.setNoButtonToPost(true);
      dialogPage.setPostToCallingPage(true);

      // Now set our Yes/No labels instead of the default OK/Cancel.
      dialogPage.setOkButtonLabel("Yes"); 
      dialogPage.setNoButtonLabel("No");

      java.util.Hashtable formParams = new Hashtable(1); 
      
      formParams.put("transmissionType", transmissionType);  
      dialogPage.setFormParameters(formParams);       
   
      pageContext.redirectToDialogPage(dialogPage);     

     }
     if(pageContext.getParameter("UpdateTransNoButton") != null)
     {
       String transmissionType = pageContext.getParameter("transmissionType");
       utl.log("Inside UpdateTransNoButton:Prev:transmissionType:" + transmissionType);       
       mainAM.findViewObject("ODEBillMainVO").first().setAttribute("EbillTransmissionType",transmissionType);    
     }
     if(pageContext.getParameter("UpdateTransYesButton") != null)
     {
       utl.log("Inside UpdateTransYesButton");
       
       OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO"); 
       String docType = docType = custDocVO.first().getAttribute("DocType").toString();     
       
       String emailSubj = null;       
       if (docType.equals("Invoice"))
         emailSubj = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SUB_STAND");
       else
         emailSubj = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SUB_CONSOLI"); 
           
       String emailStdMsg = pageContext.getProfile("XXOD_EBL_EMAIL_STD_MSG");
       String emailSign = pageContext.getProfile("XXOD_EBL_EMAIL_STD_SIGN");
       String emailStdDisc = pageContext.getProfile("XXOD_EBL_EMAIL_STD_DISCLAIM");  
       emailStdDisc = emailStdDisc + pageContext.getProfile("XXOD_EBL_EMAIL_STD_DISCLAIM1");         
       String emailSplInst = pageContext.getProfile("XXOD_EBL_EMAIL_SPL_INSTRUCT");

       String ftpEmailSubj = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_SUBJ");
       String ftpEmailCont = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_CONT");
       String ftpNotiFileTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_FILE_TEXT");  
       String ftpNotiEmailTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT"); 
       ftpNotiEmailTxt = ftpNotiEmailTxt + pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT1");  
       String transmissionType = (String) mainAM.invokeMethod("handleTransPPR");  
       Serializable transmissionParams[] = { emailSubj, emailStdMsg, emailSign, emailStdDisc, emailSplInst
                                           , ftpEmailSubj, ftpEmailCont, ftpNotiFileTxt, ftpNotiEmailTxt
                                           }; 
       mainAM.invokeMethod("defaultTrans", transmissionParams ); 
       
       if (transmissionType.equals("EMAIL"))
       {
         OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
         subTabsBean.hideSubTab(1, false);  
       }
       else 
       {
         OASubTabLayoutBean subTabsBean = (OASubTabLayoutBean)webBean.findIndexedChildRecursive("EBillSubTabRN");
         subTabsBean.hideSubTab(1, true);  
       }
       if(transmissionType.equals("FTP"))
       {
         Serializable notifyParams[] = { ftpEmailSubj, ftpEmailCont};
         mainAM.invokeMethod("handleNotifyCustPPR", notifyParams ); 
       
         Serializable sendZeroParams[] = { ftpNotiFileTxt, ftpNotiEmailTxt};       
         mainAM.invokeMethod("handleSendZeroPPR", sendZeroParams );
       }       

       OAException message = new OAException("Transmission Type changed.", OAException.INFORMATION);
       pageContext.putDialogMessage(message);       
     
     }

    /* Code to handle Contact delete button */
    if ("deleteContact".equals(pageContext.getParameter(EVENT_PARAM)))
    {
      String eblDocContactId = pageContext.getParameter("eblDocContactId");
      String contactName = pageContext.getParameter("contactName");

      utl.log("eblDocContactId: " + eblDocContactId);        
      utl.log("ContactName: " + contactName);   

      MessageToken[] tokens = { new MessageToken("CONTACT_NAME", contactName)};
      OAException mainMessage = new OAException("XXCRM", "XXOD_EBL_DELETE_CONTACT", tokens);

      OADialogPage dialogPage = new OADialogPage(OAException.WARNING, mainMessage, null, "", "");

      dialogPage.setOkButtonItemName("DeleteContactYesButton");

      dialogPage.setOkButtonToPost(true);
      dialogPage.setNoButtonToPost(true);
      dialogPage.setPostToCallingPage(true);

      // Now set our Yes/No labels instead of the default OK/Cancel.
      dialogPage.setOkButtonLabel("Yes"); 
      dialogPage.setNoButtonLabel("No");

      java.util.Hashtable formParams = new Hashtable(2); 
      
      formParams.put("eblDocContactId", eblDocContactId);     
      formParams.put("contactName", contactName); 
      dialogPage.setFormParameters(formParams);     
   
      pageContext.redirectToDialogPage(dialogPage);
    }
    if (pageContext.getParameter("DeleteContactYesButton") != null)
    {    
      String eblDocContactId = pageContext.getParameter("eblDocContactId");       
      String contactName = pageContext.getParameter("contactName");
      
      Serializable[] parameters = { eblDocContactId };
      //OAApplicationModule am = pageContext.getApplicationModule(webBean);
      
      mainAM.invokeMethod("deleteContactName", parameters);   

      MessageToken[] tokens = { new MessageToken("CONTACT_NAME", contactName) };
      OAException message = new OAException("XXCRM", 
        "XXOD_EBL_DELETE_CONTACT_CONF", tokens, OAException.CONFIRMATION, null);
      pageContext.putDialogMessage(message);
    }  
     
 
    /*Code to handle File Name Field and Template Field delete buttons */
    if ( "deleteFieldName".equals(pageContext.getParameter(EVENT_PARAM)) || "deleteTemplField".equals(pageContext.getParameter(EVENT_PARAM)) )
    {
      String pkId = pageContext.getParameter("pkId");      
      String eventName = pageContext.getParameter(EVENT_PARAM); 
      String fieldId = null;  
      utl.log("Inside deleteFieldName pkId: " + pkId);      

      OAViewObject fieldPVO, nameVO;
      OARow curRow;

      if ("deleteFieldName".equals(eventName))
      {
        nameVO = (OAViewObject) mainAM.findViewObject("ODEBillFileNameVO");
        utl.log("Inside deleteFieldName ODEBillFileNameVO Row Count: " + nameVO.getRowCount() ); 
        curRow = (OARow) nameVO.first();
        for (int i = 0 ; i < nameVO.getRowCount(); i++)
        {
          utl.log("Inside deleteFieldName ODEBillFileNameVO EblFileNameId: " + curRow.getAttribute("EblFileNameId") + ":Field Id: " + curRow.getAttribute("FieldId")); 
          if (pkId.equals( curRow.getAttribute("EblFileNameId").toString()) )
          {
            if (curRow.getAttribute("FieldId") != null)
            fieldId = curRow.getAttribute("FieldId").toString(); 
            break ;  
          }
          curRow = (OARow)  nameVO.next();
        }
      }
      else
      {
        nameVO = (OAViewObject) mainAM.findViewObject("ODEBillNonStdVO");
        utl.log("Inside deleteFieldName ODEBillTemplDtlVO Row Count: " + nameVO.getRowCount() );    
        curRow = (OARow) nameVO.first();
        for (int i = 0 ; i < nameVO.getRowCount(); i++)
        {
          utl.log("Inside deleteFieldName ODEBillTemplDtlVO EblTemplId: " + curRow.getAttribute("EblTemplId") + ":Field Id: " + curRow.getAttribute("FieldId")); 
          if (pkId.equals(curRow.getAttribute("EblTemplId").toString()) ) 
          {
            if (curRow.getAttribute("FieldId") != null)
              fieldId = curRow.getAttribute("FieldId").toString(); 
            break ;  
          }
          curRow = (OARow)  nameVO.next();
        }         
      } 
      String fieldName;
      if (fieldId != null)
      {
        Serializable[] fieldIdPara = {fieldId}; 
        fieldName = (String) mainAM.invokeMethod("getFieldName", fieldIdPara );
      }
      else
       fieldName = "EMPTY";

      MessageToken[] tokens = { new MessageToken("FIELD_NAME", fieldName)};
      OAException mainMessage = new OAException("XXCRM", "XXOD_EBL_DELETE_FIELDNAME", tokens);

      OADialogPage dialogPage = new OADialogPage(OAException.WARNING, mainMessage, null, "", "");

      dialogPage.setOkButtonItemName("DeleteFieldYesButton");

      dialogPage.setOkButtonToPost(true);
      dialogPage.setNoButtonToPost(true);
      dialogPage.setPostToCallingPage(true);

      // Now set our Yes/No labels instead of the default OK/Cancel.
      dialogPage.setOkButtonLabel("Yes"); 
      dialogPage.setNoButtonLabel("No");

      java.util.Hashtable formParams = new Hashtable(3); 
      
      formParams.put("pkId", pkId);     
      formParams.put("fieldName", fieldName);       
      formParams.put("eventName", eventName);       
      dialogPage.setFormParameters(formParams); 
      
      utl.log("Inside deleteFieldName: " + pkId);   
      pageContext.redirectToDialogPage(dialogPage);
    }
    if (pageContext.getParameter("DeleteFieldYesButton") != null)
    {    
      String pkId = pageContext.getParameter("pkId");
      String fieldName = pageContext.getParameter("fieldName"); 
      String eventName = pageContext.getParameter("eventName");

      utl.log("Inside DeleteFieldYesButton: event: " + eventName );    

      Serializable[] parameters = {pkId}; 
      if ("deleteFieldName".equals(eventName)) 
        mainAM.invokeMethod("deleteFileName", parameters);
      else
        mainAM.invokeMethod("deleteNonStdRow", parameters); 

      utl.log("Inside DeleteFieldYesButton: after delete: ");         
      
      MessageToken[] tokens = { new MessageToken("FIELD_NAME", fieldName) };
      OAException message = new OAException("XXCRM", 
        "XXOD_EBL_DELETE_FIELDNAME_CONF", tokens, OAException.CONFIRMATION, null);
      pageContext.putDialogMessage(message);
    } 

    //Code to handle Sub Total delete button
    if ("deleteSubTotal".equals(pageContext.getParameter(EVENT_PARAM)))
    {
  
      String eblAggrId = pageContext.getParameter("eblAggrId");
      String aggrFieldId = null;
      
      utl.log("Inside ODEBillMainCO deleteSubTotal: " + eblAggrId);        

      OAViewObject fieldPVO, nameVO;
      OARow curRow;
      
      nameVO = (OAViewObject) mainAM.findViewObject("ODEBillStdAggrDtlVO");
      utl.log("Inside deleteFieldName ODEBillFileNameVO Row Count: " + nameVO.getRowCount() ); 
      curRow = (OARow) nameVO.first();
      for (int i = 0 ; i < nameVO.getRowCount(); i++)
      {
        utl.log("Inside deleteSubTotal ODEBillStdAggrDtlVO EblAggrId: " + curRow.getAttribute("EblAggrId") + ":AggrField Id: " + curRow.getAttribute("AggrFieldId")); 
        if (eblAggrId.equals( curRow.getAttribute("EblAggrId").toString()) )
        {
          if (curRow.getAttribute("AggrFieldId") != null)
          aggrFieldId = curRow.getAttribute("AggrFieldId").toString(); 
          break ;  
        }
        curRow = (OARow)  nameVO.next();
      }

      String aggrFieldName;
      if (aggrFieldId != null)
      {
        Serializable[] fieldIdPara = {aggrFieldId}; 
        aggrFieldName = (String) mainAM.invokeMethod("getFieldName", fieldIdPara );
      }
      else
       aggrFieldName = "EMPTY";

      MessageToken[] tokens = { new MessageToken("AGGRFIELD_NAME", aggrFieldName)};
      OAException mainMessage = new OAException("XXCRM", "XXOD_EBL_DELETE_SUBTOTAL", tokens);
      OADialogPage dialogPage = new OADialogPage(OAException.WARNING, mainMessage, null, "", "");

      dialogPage.setOkButtonItemName("DeleteSubTotalYesButton");

      dialogPage.setOkButtonToPost(true);
      dialogPage.setNoButtonToPost(true);
      dialogPage.setPostToCallingPage(true);

      // Now set our Yes/No labels instead of the default OK/Cancel.
      dialogPage.setOkButtonLabel("Yes"); 
      dialogPage.setNoButtonLabel("No");

      java.util.Hashtable formParams = new Hashtable(1); 
      
      formParams.put("eblAggrId", eblAggrId);     
      formParams.put("aggrFieldName", aggrFieldName);       

      dialogPage.setFormParameters(formParams);     
   
      pageContext.redirectToDialogPage(dialogPage);
    }
    if (pageContext.getParameter("DeleteSubTotalYesButton") != null)
    {    
      String eblAggrId = pageContext.getParameter("eblAggrId"); 
      String aggrFieldName = pageContext.getParameter("aggrFieldName"); 
      
      Serializable[] parameters = { eblAggrId };
      //OAApplicationModule am = pageContext.getApplicationModule(webBean);
      
      mainAM.invokeMethod("deleteSubTotal", parameters);   

      MessageToken[] tokens = { new MessageToken("AGGRFIELD_NAME", aggrFieldName) };
      OAException message = new OAException("XXCRM", 
        "XXOD_EBL_DELETE_SUBTOTAL_CONF", tokens, OAException.CONFIRMATION, null); 
        
      pageContext.putDialogMessage(message);
    }

    
    if ("AddContact".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {
      utl.log("Inside PFR Add Contact" );      
      String custDocId = pageContext.getParameter("custDocId");       
      String custAcctId = pageContext.getParameter("custAcctId");  
      String payDocInd = pageContext.getParameter("payDocInd");
      String siteUseCode = null;
      utl.log("Inside PFR Add Contact:payDocInd:" + payDocInd + ":");  
     
      if ("Y".equals(payDocInd))
        siteUseCode = "BILL_TO";
      else
        siteUseCode = "SHIP_TO";
      utl.log("Inside PFR Add Contact custDocId:" + custDocId + ":custAcctId:" + ":siteUseCode:" + siteUseCode  );         
      Serializable[] parameters = { custDocId, custAcctId, siteUseCode };
      mainAM.invokeMethod("addContact", parameters);  
    }
    if ("AddFileName".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {
      utl.log("Inside PFR Add File Name" );    
      String custDocId = pageContext.getParameter("custDocId");       
      Serializable[] parameters = { custDocId };
      mainAM.invokeMethod("addFileName", parameters);  
    } 
    if ("AddNonStdField".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {
      utl.log("Inside PFR Add Non Std Field" );      
      String custDocId = pageContext.getParameter("custDocId");       
      Serializable[] parameters = { custDocId };
      mainAM.invokeMethod("addNonStdField", parameters);  
    }     
    if ("AddSubTotal".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {
      utl.log("Inside PFR Add Sub Total" );      
      String custDocId = pageContext.getParameter("custDocId");       
      Serializable[] parameters = { custDocId };
      mainAM.invokeMethod("addSubTotal", parameters);  
    } 
    if ("ChangeStdCont".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {
      utl.log("Inside PFR Change Std Cont" );      
      OAException mainMessage = new OAException("XXCRM", "XXOD_EBL_CHANGE_STD_CONT");

      String custDocId = pageContext.getParameter("custDocId");       
      String stdContLvl = pageContext.getParameter("stdContLvl");  
      utl.log("Inside CancelStdCont:Poplistchange:custDocId:" + custDocId);       
      utl.log("Inside CancelStdCont:Poplistchange:stdContLvl:" + stdContLvl);       
      

      OADialogPage dialogPage = new OADialogPage(OAException.WARNING, mainMessage, null, "", "");

      dialogPage.setOkButtonItemName("DeleteStdCont");
      dialogPage.setNoButtonItemName("CancelStdCont");

      dialogPage.setOkButtonToPost(true);
      dialogPage.setNoButtonToPost(true);
      dialogPage.setPostToCallingPage(true);

      // Now set our Yes/No labels instead of the default OK/Cancel.
      dialogPage.setOkButtonLabel("Yes"); 
      dialogPage.setNoButtonLabel("No");

      java.util.Hashtable formParams = new Hashtable(2); 
      
      formParams.put("custDocId", custDocId);     
      formParams.put("stdContLvl", stdContLvl);       
      dialogPage.setFormParameters(formParams);      
   
      pageContext.redirectToDialogPage(dialogPage);  
      pageContext.forwardImmediatelyToCurrentPage(null,true,OAWebBeanConstants.ADD_BREAD_CRUMB_YES);      

    }
    if (pageContext.getParameter("CancelStdCont") != null)
    { 
       String stdContLvl = pageContext.getParameter("stdContLvl");
       utl.log("Inside CancelStdCont:Prev:stdContLvl:" + stdContLvl);       
       mainAM.findViewObject("ODEBillMainVO").first().setAttribute("Attribute1",stdContLvl);    
    
    }
    if (pageContext.getParameter("DeleteStdCont") != null)
    {    
      utl.log("Inside PFR DeleteStdCont Event:" );  
      mainAM.invokeMethod("stdPPRHandle");  
      OAException message = new OAException("XXCRM", 
        "XXOD_EBL_CHANGE_STD_CONT_CONF", null, OAException.CONFIRMATION, null);
      pageContext.putDialogMessage(message);
      utl.log("End of PFR DeleteStdCont Event:" );        
    }  
    if ("AddStdRow".equals(pageContext.getParameter(EVENT_PARAM) ))
    {    
      utl.log("Inside PFR AddStdRow Event" );     
      mainAM.invokeMethod("stdPPRHandle");  
    }      
    
    if ("CompRequired".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR CompRequired Event: zipRequired: " );  
      mainAM.invokeMethod("handleCompressPPR" );  
    } 

    if ("FileDelimited".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR fileDelimited Event: " );  
      mainAM.invokeMethod("handleDelimitedPPR" );  
    }  

    if ("LogoReq".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR LogoReq Event: " );  
      mainAM.invokeMethod("handleLogoReqPPR" );  
    } 

    if ("NSFieldChange".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR NSFieldChange Event: " );  
      String  eblTemplId = pageContext.getParameter("eblTemplId") ;
      utl.log("Inside PFR NSFieldChange Event: eblTemplId: " + eblTemplId );        
      Serializable[] parameters = { eblTemplId};           
      mainAM.invokeMethod("handleNSFieldChangePPR", parameters );  
    }     
    if ("NotifyCust".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR NotifyCust Event: " ); 
      String ftpEmailSubj = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_SUBJ");
      String ftpEmailCont = pageContext.getProfile("XXOD_EBL_FTP_EMAIL_CONT");      
      Serializable[] parameters = { ftpEmailSubj,  ftpEmailCont};      
      mainAM.invokeMethod("handleNotifyCustPPR", parameters );  
    } 
    if ("ZeroByte".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR ZeroByte Event: " );
      String ftpNotiFileTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_FILE_TEXT");  
      String ftpNotiEmailTxt = pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT");        
      ftpNotiEmailTxt = ftpNotiEmailTxt + pageContext.getProfile("XXOD_EBL_FTP_NOTIFI_EMAIL_TEXT1");      
      Serializable[] parameters = { ftpNotiFileTxt, ftpNotiEmailTxt };      
      mainAM.invokeMethod("handleSendZeroPPR", parameters );  
    }     
    /* Handle for create contact button. To create new contacts and contact points with 
     * email for the customer with responsibility type and contact point purpose as BILLING */
    if ("CreateContact".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR CreateContact Event:");  
      OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO");
      OARow custDocRow = null;
      if (custDocVO != null)
        custDocRow = (OARow) custDocVO.first();
        
      if (custDocRow != null)
      {
        HashMap params = new HashMap(5);  
        params.put("OAFunc", "ASN_CTCTCREATEPG");
        params.put("ASNReqFrmCustName", custDocRow.getAttribute("PartyName"));
        params.put("ASNReqFrmPgMode", "CREATE");
        params.put("ASNReqFrmFuncName", "ASN_CTCTCREATEPG");
        params.put("ASNReqFrmCustId", custDocRow.getAttribute("PartyId"));
        params.put("ODEBillCustAccId", custDocRow.getAttribute("CustAccountId") );
        params.put("ODEBillParentPage", "ODEBillMainPG" );      

        pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/asn/common/customer/webui/ODCtctCreatePG",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null,
                                      false, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES); 
      }
      
    }
    /* Handle for create contact button. To update existing contacts and contact points with 
     * email for the customer with responsibility type and contact point purpose as BILLING */    
    if ("UpdateContact".equals(pageContext.getParameter(EVENT_PARAM) ) )
    { 

      String ReqFrmCtctId = null;
      String ReqFrmCtctName = null;      
      String ReqFrmRelPtyId = null;
      String ReqFrmRelId = null;
      String ReqFrmRelPtyName = null;

      OADBTransactionImpl oadbtransactionimpl = (OADBTransactionImpl)mainAM.getOADBTransaction();
      utl.log("Inside PFR UpdateContact Event:");  
      
      OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO");
      OARow custDocRow = null;
      if (custDocVO != null)
        custDocRow = (OARow) custDocVO.first();
      if (custDocRow != null)
      {      
        String orgContactId = pageContext.getParameter("orgContactId");
       utl.log("Inside PFR UpdateContact Event:orgContactId" + orgContactId);         
        if (orgContactId == null)
         throw new OAException("You need to select a contact before updationg contact details");

        String contDet = "SELECT HR.relationship_id"
                          + " ,  HPHR.party_name relationship_name"        
                          + " ,  HR.party_id"
                          + " ,  HR.subject_id"
                          + " ,  HP.party_name subject_name"
                          + " ,  HR.object_id"
                          + " FROM hz_org_contacts HOC"
                          + "    , hz_relationships HR"
                          + "    , hz_parties HP"
                          + "    , hz_parties HPHR"
                          + " WHERE HOC.party_relationship_id = HR.relationship_id"
                          + "   AND HR.relationship_code = 'CONTACT_OF'"
                          + "   AND HR.subject_id = HP.party_id"
                          + "   AND HR.party_id = HPHR.party_id"                          
                          + "   AND HOC.org_contact_id = " +  orgContactId;

        try
        {                            
          OracleCallableStatement contCall = (OracleCallableStatement)oadbtransactionimpl.createCallableStatement(contDet, -1);          
          ResultSet contRS = (OracleResultSet) contCall.executeQuery();

          if (contRS.next())
          {
            ReqFrmCtctId = contRS.getString("subject_id");
            ReqFrmCtctName = contRS.getString("subject_name");            
            ReqFrmRelPtyId = contRS.getString("relationship_id");
            ReqFrmRelPtyName = contRS.getString("relationship_name");  
            ReqFrmRelId = contRS.getString("party_id"); 
            contRS.close();
            contCall.close();
          }// if (contRS.next())            

        }//end try
        catch(SQLException sqlexception)
        {
            throw OAException.wrapperException(sqlexception);
        }
        catch(Exception exception)
        {
           utl.log("Inside PFR UpdateContact Event: Exception");       
            throw OAException.wrapperException(exception);
        }             
  /*
        HashMap params = new HashMap(10);  
        params.put("OAFunc", "ASN_CTCTUPDATEPG");
        params.put("ODReqFrmCustName", custDocRow.getAttribute("PartyName"));
        params.put("ASNReqFrmPgMode", "UPDATE");
        params.put("ASNReqFrmFuncName", "ASN_CTCTUPDATEPG");
        params.put("ASNReqFrmCustId", custDocRow.getAttribute("PartyId"));

        params.put("ASNReqFrmCtctId", ReqFrmCtctId );
        params.put("ODReqFrmCtctName", ReqFrmCtctName);        
        params.put("ASNReqFrmRelPtyId", ReqFrmRelPtyId );
        params.put("ASNReqFrmRelId", ReqFrmRelId );

        params.put("ODEBillCustAccId", custDocRow.getAttribute("CustAccountId") );
        params.put("ODEBillParentPage", "ODEBillMainPG" );  

    pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/asn/common/customer/webui/ODCtctUpdatePG",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null,
                                      false, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES); */
                                      
        HashMap params = new HashMap(10);  
        params.put("ImcPartyId", ReqFrmRelPtyId );
        params.put("ImcPartyName", ReqFrmRelPtyName);  //"Anitha Dev - AXIS - Organization Contact");
        params.put("ImcMainPartyId", ReqFrmCtctId ); 
        params.put("HzPuiMainPartyId", ReqFrmCtctId ); 
        params.put("ImcGenPartyId", ReqFrmRelId ); 

        utl.log("ReqFrmRelPtyId: " + ReqFrmRelPtyId);          
        utl.log("ReqFrmCtctId: " + ReqFrmCtctId);          

        pageContext.forwardImmediately("OA.jsp?page=/oracle/apps/imc/ocong/contactpoints/webui/ImcPerContPoints",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null,
                                      false, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES);
 
      }// if (custDocRow != null)
     
    } //    if ("UpdateContact".equals(pageContext.getParameter(EVENT_PARAM) ) )    
   /* Handling Change to Complete button click. Data in the screen is saved. 
      Status of the customer doc is changed to complete if the validations are successful */
   if ("ChangeStatus".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {   
      utl.log("Inside PFR ChangeStatus Event:"); 
      OAViewObject custDocVO = (OAViewObject) mainAM.findViewObject("ODEBillCustHeaderVO");        
      String custDocId = custDocVO.first().getAttribute("CustDocId").toString();
      String custAccountId = custDocVO.first().getAttribute("CustAccountId").toString();      
      String deliveryMethod = custDocVO.first().getAttribute("DeliveryMethod").toString(); 
      
      Serializable[] applyMainPara = { deliveryMethod };      
      mainAM.invokeMethod("applyMain", applyMainPara);
      
      Serializable[] validateFinalpara = { custDocId, custAccountId };
      utl.log("Inside PFR ChangeStatus Event: validationFinal Before Validate Final:");       
      String returnStatus = (String) mainAM.invokeMethod("validateFinal", validateFinalpara); 
      utl.log("Inside PFR ChangeStatus Event: validationFinal After Validate Final: returnStatus:" + returnStatus);       

      HashMap params = new HashMap(1);  
      params.put("changeStatus", returnStatus);

      utl.log("**Inside PFR ChangeStatus Event: before endTransactionUnit" + returnStatus);        
      TransactionUnitHelper.endTransactionUnit(pageContext, "MainTxn");       
      pageContext.forwardImmediatelyToCurrentPage(params,false,OAWebBeanConstants.ADD_BREAD_CRUMB_YES); 

    } 
  
  }//End of processFormRequest
 
}
