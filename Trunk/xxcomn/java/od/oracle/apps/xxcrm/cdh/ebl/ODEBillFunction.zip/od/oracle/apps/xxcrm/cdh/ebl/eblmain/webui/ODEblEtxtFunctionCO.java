/*===========================================================================+
 |   Copyright (c) 2001, 2003 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package od.oracle.apps.xxcrm.cdh.ebl.eblmain.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.OAApplicationModule;
import com.sun.java.util.collections.HashMap;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.OAException;

/**
 * Controller for ...
 */
public class ODEblEtxtFunctionCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    OAViewObject eTxtFunVO=(OAViewObject) am.findViewObject("ODEblEtxtFunctionsVO");
    if (eTxtFunVO.isPreparedForExecution())
      eTxtFunVO.executeQuery();

    if (eTxtFunVO.getRowCount()==0)
    {
      OARow curRow = (OARow)eTxtFunVO.createRow();
      eTxtFunVO.insertRow(curRow);
    }
    String CplxFun=(String)pageContext.getSessionValue("CplxFun");
    if (CplxFun!=null)
    {
       pageContext.writeDiagnostics(this,"Complex Function :"+CplxFun,5);
       throw new OAException("Function Returned from Validator : "+CplxFun);
    }
    else
       pageContext.writeDiagnostics(this,"No Complex Function Returned",5);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    OAViewObject eTxtFunVO=(OAViewObject) am.findViewObject("ODEblEtxtFunctionsVO");
    if (pageContext.getParameter("Create") != null)
    {    
      /*if (eTxtFunVO.isPreparedForExecution())
        eTxtFunVO.executeQuery();
      */

      eTxtFunVO.last();
      eTxtFunVO.next();
      OARow curRow = (OARow)eTxtFunVO.createRow();
      eTxtFunVO.insertRow(curRow);
    }
    if (pageContext.getParameter("Apply") != null)
    {    
      am.getTransaction().commit();
    }
    //pageContext.writeDiagnostics(this,"Parameter Values:"+fun+" col "+col1,5);
    if ("CplxFun".equals(pageContext.getParameter(EVENT_PARAM) ) )
    {    
        pageContext.writeDiagnostics(this,"Inside PPR Function",5);
        String fun=pageContext.getParameter("Function");
        String col1=pageContext.getParameter("Column1");
        HashMap params = new HashMap(10);  
        params.put("Function", fun); 
        params.put("Column1", col1); 

        pageContext.writeDiagnostics(this,"Parameter Values:"+fun+" col "+col1,5);

        pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/cdh/ebl/eblmain/webui/ODEBillFunc",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null, //params
                                      true, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES);
       
    }

  }

}
