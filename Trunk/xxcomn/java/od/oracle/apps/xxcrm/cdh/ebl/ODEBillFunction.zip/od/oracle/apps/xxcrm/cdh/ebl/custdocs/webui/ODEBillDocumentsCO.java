package od.oracle.apps.xxcrm.cdh.ebl.custdocs.webui;

/*
-- +===========================================================================+
  -- |                  Office Depot - eBilling Project                          |
  -- |                         WIPRO/Office Depot                                |
  -- +===========================================================================+
  -- | Name        : ODEBillDocumentsCO                                         |
  -- | Description :                                                             |
  -- |        |
  -- |                                                                           |
  -- |                                                                           |
  -- |                                                                           |
  -- |Change Record:                                                             |
  -- |===============                                                            |
  -- |Version  Date        Author        Remarks                                 |
  -- |======== =========== ============= ========================================|
  -- |DRAFT 1A 24-FEB-2010 Vasan S       Initial draft version                   |
  -- |                                                                           |
  -- |                                                                           |
  -- |                                                                           |
  -- |===========================================================================|                         
  -- | Subversion Info:                                                          |
  -- | $HeadURL: http://svn.na.odcorp.net/od/common/branches/10.4/xxcomn/java/od/oracle/apps/xxcrm/cdh/ebl/custdocs/webui/ODEBillDocumentsCO.java $                                                               |
  -- | $Rev: 113643 $                                                                   |
  -- | $Date: 2010-09-14 00:18:12 +0530 (Tue, 14 Sep 2010) $                                                                  |
  -- |                                                                           |
  -- +===========================================================================+
*/
import com.sun.java.util.collections.HashMap;
import java.io.Serializable;
import java.text.SimpleDateFormat;
//import java.util.Calendar;

import od.oracle.apps.xxcrm.cdh.ebl.server.ODUtil;
import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.table.OAAdvancedTableBean;

import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;

/**
 * Controller for ...
 */
public class ODEBillDocumentsCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    String event=pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
    super.processRequest(pageContext, webBean);
    OAApplicationModule CustDocAM = (OAApplicationModule) pageContext.getApplicationModule(webBean);
    ODUtil utl = new ODUtil(CustDocAM);
    utl.log("Event :"+event);
    utl.log("ODEBillDocumentsCO:Process Request Begin");
    String AccountNumber = pageContext.getParameter("accountNumber"); 
    String CustAccountId = pageContext.getParameter("custAccountId"); 
    String custName = pageContext.getParameter("custName"); 
    //pageContext.getPageLayoutBean().setTitle("Billing Documents For Customer:"+custName+" Account Number:"+ AccountNumber); 
    pageContext.getPageLayoutBean().setTitle("Customer Billing Documents");

    OAAdvancedTableBean advtableBean = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("EbillCustDocAdvTblRN");
    advtableBean.setAllDetailsEnabled(true);   
    //Query Header View Object
    OAViewObject HdrVO = (OAViewObject) CustDocAM.findViewObject("ODEBillCustDocHeaderVO");
    HdrVO.setWhereClause(null);  
    HdrVO.setWhereClause("CUST_ACCOUNT_ID = " + CustAccountId );
    HdrVO.executeQuery();
    //Detail View Object Query
    OAViewObject CustDocVO = (OAViewObject) CustDocAM.findViewObject("ODEbillCustDocVO");
    if (!CustDocVO.isPreparedForExecution())
    {
      CustDocVO.setWhereClause(null);  
      CustDocVO.setWhereClause("CUST_ACCOUNT_ID = " + CustAccountId );
      utl.log("Query Where Clause :"+CustDocVO.getWhereClause());
      CustDocVO.executeQuery();
      CustDocVO.last();
      while(CustDocVO.hasPrevious())
      {
        if(CustDocVO.getCurrentRow().getAttribute("DExtAttr2")!=null)
          CustDocVO.getCurrentRow().setAttribute("Paydocind",Boolean.TRUE);
  /*      else//End Date is Null
        {
          Boolean sup=(Boolean)CustDocVO.getCurrentRow().getAttribute("Supusrend");
          //Disable End Date for super user, If End Date is NULL
          if(!sup.booleanValue())
            CustDocVO.getCurrentRow().setAttribute("Supusrend",Boolean.TRUE);

        }
  */
        CustDocVO.previous();
      }
    }
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    String AccountNumber = pageContext.getParameter("accountNumber"); 
    String CustAccountId = pageContext.getParameter("custAccountId");

    OAApplicationModule am=pageContext.getApplicationModule(webBean);
    ODUtil utl = new ODUtil(am);
    utl.log("ODEBillDocumentsCO:Process Form Request Begin");
    utl.log("Event :"+pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM));
    //Cancel Button Clicked
    if ( "Cancel".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
      OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
      int lcnt = CustDocVO.getRangeStart();
      //int lSize= CustDocVO.getRangeSize();
      if(am.getTransaction().isDirty()) 
        am.getTransaction().rollback();
      CustDocVO.setWhereClause("CUST_ACCOUNT_ID = " + CustAccountId );
      utl.log("Query Where Clause :"+CustDocVO.getWhereClause());
      utl.log("setting to page "+lcnt);
      CustDocVO.executeQuery();     
      gotoPage(lcnt,CustDocVO);

    }
    //If user tries to Navigate to eBill main page.
    if ( "Navigate".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
       if(am.getTransaction().isDirty()) 
       {
         throw new OAException("XXCRM","XXOD_EBL_UNSAVED_DATA");
       }
       HashMap params = new HashMap();
       String custDocID = pageContext.getParameter("CustDocID");
       String dlyMethod = pageContext.getParameter("DlyMtd");
       params.put("custAccountId",CustAccountId);
       params.put("custDocId",custDocID);
       params.put("deliveryMethod",dlyMethod);
       utl.log("Value "+custDocID+" doc Id "+dlyMethod);
       pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/cdh/ebl/eblmain/webui/ODEBillMainPG",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null,
                                      false, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES);

    }
    //Exception Button Clicked
    if ( "Exception".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
       if(am.getTransaction().isDirty()) 
       {
         throw new OAException("XXCRM","XXOD_EBL_UNSAVED_DATA");
       }
       HashMap params = new HashMap();
       params.put("CustAccountId",CustAccountId);
       pageContext.forwardImmediately("OA.jsp?page=/od/oracle/apps/xxcrm/cdh/ebl/exec/webui/ODEBillDocExceptionPG",
                                      null,
                                      OAWebBeanConstants.KEEP_MENU_CONTEXT,
                                      null,
                                      params, //null,
                                      false, // retain AM
                                      OAWebBeanConstants.ADD_BREAD_CRUMB_YES);
    }
    //Save Button Clicked
    if ( "Save".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
        utl.log("ODEBillDocumentsCO:Inside Save PPR");
        utl.log("ODEBillDocumentsCO:Validating");
        OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
        utl.log("Testing the Current start :"+CustDocVO.getRangeStart());
        int lcnt = CustDocVO.getRangeStart();
        int lSize= CustDocVO.getRangeSize();
        //Validate Method to validate user Entered Data.
        validateCustDoc(pageContext,webBean);
        utl.log("ODEBillDocumentsCO:Before Commit");
        am.getTransaction().setClearCacheOnCommit(true);
        am.getTransaction().commit();
        am.getTransaction().setClearCacheOnCommit(false);
        //end if
        CustDocVO.last();
        CustDocVO.first();

        CustDocVO.setRangeStart(lcnt);
        utl.log("ODEBillDocumentsCO:Commit End");
        OAException confirmMessage = new OAException("XXCRM","XXOD_EBL_DOC_SAVE_SUCCESS",null, OAException.INFORMATION,null);
        pageContext.putDialogMessage(confirmMessage); 
        //throw new OAException("XXCRM","XXOD_EBL_UNSAVED_DATA",OAException.INFORMATION);
        //throw new OAException("Customer Document Save Successful",OAException.INFORMATION);
    }//Save
    //Add Row Button Clicked
    if ("AddRow".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
        String payTerm = pageContext.getProfile("XXOD_EBL_DEFAULT_PAYTERM");
        String curdate = pageContext.getCurrentDBDate().toString();

        Serializable inputParams[] = {CustAccountId,payTerm,curdate};
        Object strGrpID = am.invokeMethod("addRow", inputParams);

    }//AddRow
    //PPR for Dely method Change
    if ( "DelyMtdUpdate".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
    {
        String dlyMtd = pageContext.getParameter("DelyMtdUpdate");
        String custDocId=pageContext.getParameter("CustDocId");
        utl.log("ODEBillDocumentsCO:Inside DelyMtdUpdate PPR for:"+custDocId);
        String qry="SELECT count(1) "+ 
                   "FROM xx_cdh_ebl_main "+
                   "WHERE cust_doc_id="+custDocId;
        //Code to Retain Page number on this action
        OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
        String rowCount = Integer.toString(CustDocVO.getRangeStart());
        String attrGrpId= CustDocVO.getCurrentRow().getAttribute("AttrGroupId").toString();

        Serializable inputParams[] = {qry};
        Number ln_cnt = (Number)am.invokeMethod("execQuery", inputParams);
        utl.log("Count of Rows:"+ln_cnt.toString());
        if(!"0".equals(ln_cnt.toString()))
        {
        OAException delMsg=new OAException("XXCRM","XXOD_EBL_DEL_TEMPL_CONFIG");
        OADialogPage dialogPage=new OADialogPage(OAException.WARNING,delMsg,null,"","");
        dialogPage.setOkButtonItemName("DeleteYesButton");
        dialogPage.setNoButtonItemName("DeleteNoButton");
        dialogPage.setOkButtonToPost(true);
        dialogPage.setNoButtonToPost(true);
        dialogPage.setPostToCallingPage(true);
        dialogPage.setOkButtonLabel("Yes"); 
        dialogPage.setNoButtonLabel("No");
        java.util.Hashtable formParams = new java.util.Hashtable(1); 
        formParams.put("CustDocId", custDocId); 
        formParams.put("RowCount", rowCount); 
        formParams.put("AttrGrpId", attrGrpId); 
        formParams.put("DlyMtd",dlyMtd);
        dialogPage.setFormParameters(formParams); 
        pageContext.redirectToDialogPage(dialogPage);
        }

    }//DelyMtdUpdate
    if (pageContext.getParameter("DeleteYesButton") != null)
    {
      String custDocId=pageContext.getParameter("CustDocId");
      String rowCount  = pageContext.getParameter("RowCount");
      String dlyMtd = pageContext.getParameter("DlyMtd");
      try{
      Number nCustdoc  = new Number(custDocId);
      utl.log("Invoking Delete method to Delete Conf Data for "+custDocId+dlyMtd);
      OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
      OARow curRow = (OARow)CustDocVO.getFirstFilteredRow("NExtAttr2",nCustdoc);
      String curDlyMtd=(String)curRow.getAttribute("CExtAttr3");
      utl.log("Invoking Delete method to Delete Conf Data for "+curDlyMtd);
      Serializable inputParams[] = {custDocId,curDlyMtd};
      am.invokeMethod("deleteTrans", inputParams);
      int lnCnt=Integer.parseInt(rowCount);
      CustDocVO.setRangeStart(lnCnt);
      }
      catch(Exception e)
      {
        utl.log("ODEBillDocumentsCO:DeleteYesButton Error:"+e.toString());
      }      

    }//DeleteYesButton
    if (pageContext.getParameter("DeleteNoButton") != null)
    {
      String custDocId = pageContext.getParameter("CustDocId");
      String rowCount  = pageContext.getParameter("RowCount");
      String attrGrpId = pageContext.getParameter("AttrGrpId");
      String dlyMtd = pageContext.getParameter("DlyMtd");
      try{
      Number nCustdoc  = new Number(custDocId);
      /*
      utl.log("Delete No handle for "+custDocId+" row "+rowCount);
      String qry="SELECT C_EXT_ATTR3 "+
              " FROM   XX_CDH_CUST_ACCT_EXT_B "+
              " WHERE  CUST_ACCOUNT_ID= "+CustAccountId+
              " AND    N_EXT_ATTR2= "+custDocId+
              " AND    ATTR_GROUP_ID="+attrGrpId;
      Serializable inputParams[] = { qry };
      String dlyMtd = (String)am.invokeMethod("execStrQuery", inputParams);
      */
      OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
      OARow curRow = (OARow)CustDocVO.getFirstFilteredRow("NExtAttr2",nCustdoc);

      curRow.setAttribute("CExtAttr3",dlyMtd);
      int lnCnt=Integer.parseInt(rowCount);
      CustDocVO.setRangeStart(lnCnt);
      }
      catch(Exception e)
      {
        utl.log("ODEBillDocumentsCO:DeleteNOButton Error:"+e.toString());
      }
      utl.log("Delete No handle for end");
    }//DeleteNoButton
    utl.log("ODEBillDocumentsCO:End Process Form Request");

  } //processFormRequest

/*  public int compateDate(Date d1, Date d2)
  {
    if(d1.getTime()<d2.getTime())
      return -1;
    else if(d1.getTime()>d2.getTime())
      return 1;
    else if(d1.getTime()=d2.getTime())
      return 0;
  }
*/

  /**
   * Procedure to handle Save Time validation in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   * Called from Save Action PPR.
   */

  public void validateCustDoc(OAPageContext pageContext, OAWebBean webBean)
  {
    OAApplicationModule am = (OAApplicationModule)pageContext.getApplicationModule(webBean);
    ODUtil utl = new ODUtil(am);
    utl.log("Begin validateCustDoc");
    OAViewObject CustDocVO = (OAViewObject) am.findViewObject("ODEbillCustDocVO");
    CustDocVO.last();
    utl.log("validateCustDoc: Looping through each row");
    int lnPayDocCnt=0;
    int lnDrCnt=0;
    int lnCrCnt=0;
    int lnEndDtNull=1;

    int lnPayDocFCnt=0;
    int lnDrFCnt=0;
    int lnCrFCnt=0;
        
    for (int i=1;i<=CustDocVO.getRowCount();i++)
    {
      utl.log("validateCustDoc: getting Values from VO attributes"+i);
      //Data Capture Begin
      String recStat = (String)CustDocVO.getCurrentRow().getAttribute("Intrecstatus");
      String payTerm = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr14");
      Date reqStDate = (Date)CustDocVO.getCurrentRow().getAttribute("DExtAttr9");
      Date reqEnDate = (Date)CustDocVO.getCurrentRow().getAttribute("DExtAttr10");
      String payDocInd  = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr2");
      String dlyMtd  = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr3");
      Number custDocId = (Number)CustDocVO.getCurrentRow().getAttribute("NExtAttr2");
      Number custAcctId = (Number)CustDocVO.getCurrentRow().getAttribute("CustAccountId");
          
      String dirDocFlag  = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr7");
      Number isParent = (Number)CustDocVO.getCurrentRow().getAttribute("NExtAttr17");
      Number isChild  = (Number)CustDocVO.getCurrentRow().getAttribute("NExtAttr16");
      String status   = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr16");
      String docType  = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr1");
      Number attrGrpID= (Number)CustDocVO.getCurrentRow().getAttribute("AttrGroupId");
      Date userReqStDt=reqStDate;
      String freq="DAILY";
      String payDocPayTerm=(String)CustDocVO.getCurrentRow().getAttribute("CExtAttr14");
      String comboType=(String)CustDocVO.getCurrentRow().getAttribute("CExtAttr13");

      Number nPCustdoc=(Number)CustDocVO.getCurrentRow().getAttribute("NExtAttr15");
      Number nPCustActId = (Number)CustDocVO.getCurrentRow().getAttribute("ParentCustDocID");
      //Data Capture End
      //Local Variables
      String stmt;
      String consFlag="Y";
      Date maxDt=(Date)Date.getCurrentDate();;
      String s_maxDt=maxDt.toString();
      String s_cMaxDt=maxDt.toString();
      //Local Variable Ends//

      //If parent doc id is selected. Get Payment Term for Date Calculation
      if (nPCustdoc!=null && nPCustActId!=null)
      {
         stmt = "SELECT c_ext_attr14 FROM XX_CDH_CUST_ACCT_EXT_B "
              + " WHERE attr_group_id="+attrGrpID.toString() 
              + " AND n_ext_attr2= "+nPCustdoc.toString() 
              + " AND cust_account_id="+nPCustActId.toString();
         Serializable inputParams[] = { stmt };
         payTerm = (String)am.invokeMethod("execStrQuery", inputParams);
         utl.log("payTerm from parent "+payTerm);
      }

      //Calculated Data Capture Begin
      if (reqEnDate!=null)
      {
        Serializable inputParams1[] = {  payTerm, reqEnDate.toString() };
        reqEnDate = (Date)am.invokeMethod("calculateEffDate", inputParams1); 
      }
      if (reqStDate!=null) 
      {
        Serializable inputParams2[] = {  payTerm, reqStDate.toString() };
        reqStDate = (Date)am.invokeMethod("calculateEffDate", inputParams2);
        reqStDate = new Date(reqStDate.addJulianDays(1,0));
        utl.log("Start Date "+reqStDate.toString());
      }
      //This condition required to handle 
      //in case of error due to invalid combo/non combo pay doc
      if(recStat.equals("NEW"))
      {
        status = "IN_PROCESS";
        utl.log("Status Considered as IN_PROCESS");
      }

      //If parent doc id is selected. Act accordingly
      if (nPCustdoc!=null && nPCustActId!=null)
      {
         stmt = "SELECT c_ext_attr2 FROM XX_CDH_CUST_ACCT_EXT_B "
              + " WHERE attr_group_id="+attrGrpID.toString() 
              + " AND n_ext_attr2= "+nPCustdoc.toString() 
              + " AND cust_account_id="+nPCustActId.toString();
         Serializable inputParams[] = { stmt };
         payDocInd = (String)am.invokeMethod("execStrQuery", inputParams);
         utl.log("payDocInd from parent "+payDocInd);
      }
          
      /*
      if ( payDocInd.equals("Y") && status.equals("IN_PROCESS") ) 
      {
      //Cons Inv Flag value capture
      stmt="SELECT cons_inv_flag "
           +"FROM HZ_CUSTOMER_PROFILES "
           +"WHERE cust_account_id="+custAcctId.toString()
           +" AND SITE_USE_ID is null";
      Serializable inputParams[] = { stmt };
      consFlag = (String)am.invokeMethod("execStrQuery", inputParams);
      utl.log("Consolidated Flag "+consFlag);
      }
      */

      //Effective Start date data capture.
      /*
      if ( payDocInd.equals("Y") && status.equals("IN_PROCESS")) 
      {
      //Fetching max of start date for pay doc date validation
      stmt="SELECT TO_CHAR(max(d_ext_attr1),'RRRR-MM-DD') "
           +"FROM XX_CDH_CUST_ACCT_EXT_B "
           +"WHERE cust_account_id="+custAcctId.toString()
           +" AND d_ext_attr2 is NULL"
           +" AND c_ext_attr16 = 'COMPLETE'"
           +" AND c_ext_attr2='Y'"
           +" AND attr_group_id="+attrGrpID.toString();
      Serializable inputParams5[] = { stmt };
      s_maxDt = (String)am.invokeMethod("execStrQuery", inputParams5);
      if(s_maxDt==null)
      {
        throw new OAException("XXCRM","XXOD_EBL_INVALID_PAYDOC_DATES");
      }
      */
      if ( payDocInd.equals("Y") && status.equals("IN_PROCESS")) 
      {
      //Fetching max of start date for pay doc date validation
      utl.log("combo Type "+comboType);
      stmt="SELECT TO_CHAR(XX_CDH_CUST_ACCT_EXT_W_PKG.GET_PAY_DOC_VALID_DATE("
           +custAcctId.toString()
           +","+attrGrpID.toString();
      if (comboType!=null)
         stmt=stmt +",'"+comboType+"')";
      else
         stmt=stmt +",null)";
      stmt=stmt+",'RRRR-MM-DD') FROM DUAL";
      Serializable inputParams8[] = { stmt };
      s_maxDt = (String)am.invokeMethod("execStrQuery", inputParams8);
      utl.log("Max date from GetValid Date:"+s_maxDt);
      maxDt=new Date(s_maxDt);
      stmt="SELECT TO_CHAR(TO_DATE('"+ s_maxDt +"','RRRR-MM-DD'),'DD-MON-RRRR') "
           +"FROM DUAL ";
      Serializable inputParams51[] = { stmt };
      s_maxDt = (String)am.invokeMethod("execStrQuery", inputParams51);
      utl.log("Formatted max Date:"+s_maxDt);
      }
      
      

      //Payment Frequency of pay doc
      if ( payDocInd.equals("N") && status.equals("IN_PROCESS")) 
      {
      stmt="SELECT RT.attribute1 "
           +"FROM XX_CDH_CUST_ACCT_EXT_B XCAE "
           +"    ,RA_TERMS RT "
           +"WHERE cust_account_id="+custAcctId.toString()
           +" AND to_date('"+reqStDate.toString()+"','RRRR-MM-DD') between d_ext_attr1 and nvl(d_ext_attr2,to_date('"+reqStDate.toString()+"','RRRR-MM-DD')) "
           +" AND c_ext_attr16 = 'COMPLETE' "
           +" AND c_ext_attr2='Y' "
           +" AND attr_group_id="+attrGrpID.toString()
           +" AND nvl(c_ext_attr13,'CR')='CR' "
           +" AND XCAE.N_EXT_ATTR18 = RT.term_id ";
      Serializable inputParams6[] = { stmt };
      freq = (String)am.invokeMethod("execStrQuery", inputParams6);
      if(freq==null) freq="DAILY";
      utl.log("Pay Doc Frequency "+freq);
            stmt="SELECT RT.NAME "
           +"FROM XX_CDH_CUST_ACCT_EXT_B XCAE "
           +"    ,RA_TERMS RT "
           +"WHERE cust_account_id="+custAcctId.toString()
           +" AND to_date('"+reqStDate.toString()+"','RRRR-MM-DD') between d_ext_attr1 and nvl(d_ext_attr2,to_date('"+reqStDate.toString()+"','RRRR-MM-DD')) "
           +" AND c_ext_attr16 = 'COMPLETE' "
           +" AND c_ext_attr2='Y' "
           +" AND attr_group_id="+attrGrpID.toString()
           +" AND nvl(c_ext_attr13,'CR')='CR' "
           +" AND XCAE.N_EXT_ATTR18 = RT.term_id ";
      Serializable inputParams7[] = { stmt };
      payDocPayTerm = (String)am.invokeMethod("execStrQuery", inputParams7);
      utl.log("Pay Doc PayTerm "+payDocPayTerm);
      }
      //Calculated Data Capture End

      //Validation Begin
      //user should not end date Pay Doc before its complete
      if (status.equals("IN_PROCESS") && payDocInd.equals("Y") && reqEnDate!=null)
      {
        throw new OAException("XXCRM","XXOD_EBL_ENDDATE_PAYDOC");
      }
      /*
      if (status.equals("IN_PROCESS") && payDocInd.equals("Y") 
          && consFlag.equals("N") && docType.equals("Consolidated Bill"))
      {
        throw new OAException("XXCRM","XXOD_EBL_NON_CONSOLIDATED");
      }
      */
      if(status.equals("IN_PROCESS") && nPCustdoc==null && docType.equals("Invoice") && dlyMtd.equals("ELEC"))
      {
        throw new OAException("XXCRM","XXOD_EBL_ELEC_INVOICE");
      }
      if(status.equals("IN_PROCESS") && nPCustdoc==null && !docType.equals("Invoice") && dlyMtd.equals("EDI"))
      {
        throw new OAException("XXCRM","XXOD_EBL_EDI_CONS");
      }
      if (status.equals("IN_PROCESS") && payDocInd.equals("Y") 
          && maxDt.compareTo(userReqStDt)>0 )
      {
          MessageToken[] tokens = { new MessageToken("MAX_ST_DT", s_maxDt + " for " +custDocId.toString())};
          throw new OAException("XXCRM","XXOD_EBL_INVALID_PAYDOC_ST_DT",tokens);
      }
      /*
      if (status.equals("IN_PROCESS") && payDocInd.equals("N") && !freq.equals("DAILY"))
      {
         if(!payTerm.equals(payDocPayTerm))
            throw new OAException("XXCRM","XXOD_EBL_INVALID_FREQUENCY");
      }
      */
      if ( dirDocFlag.equals("N") && isParent.intValue()==1 )
      {
        throw new OAException("XXCRM","XXOD_EBL_IS_PARENT_INDIRECT");
      }
      if ( isParent.intValue()==1 && isChild.intValue()==1 )
      {
        throw new OAException("XXCRM","XXOD_EBL_IS_PARENT_AND_CHILD");
      }
      //Validation end

      //If Status of current Row is complete, No Validation except Req End Date
      if (status!=null && status.equals("COMPLETE"))
      {
        Date endDt = (Date)CustDocVO.getCurrentRow().getAttribute("DExtAttr2");
        if (reqEnDate!=null && endDt==null )
          CustDocVO.getCurrentRow().setAttribute("DExtAttr2",reqEnDate);
      }
      else //Added insted of Continue. Row is IN_PROCESS
      {
         //If parent Document Id selected, populate from parent doc id
         if (nPCustdoc!=null && nPCustActId!=null)
         {
            String parCustdoc = nPCustdoc.toString();
            String attrGrpId  = attrGrpID.toString();
            String curCustDoc = custDocId.toString();
            //Number numCustAcc = (Number)CustDocVO.getCurrentRow().getAttribute("ParentCustDocID");
            String parCustAcc=null;
            if(isParent.intValue()==1)
            {
              throw new OAException("XXCRM","XXOD_EBL_IS_PARENT_AND_CHILD");
            }
            if(nPCustActId!=null)
            {
              parCustAcc=nPCustActId.toString();
              CustDocVO.getCurrentRow().setAttribute("DExtAttr1",reqStDate);
              CustDocVO.getCurrentRow().setAttribute("DExtAttr2",reqEnDate);
              Serializable inputParams1[] = {parCustdoc,attrGrpId,curCustDoc,parCustAcc};
              am.invokeMethod("populateCustDoc",inputParams1);
              CustDocVO.getCurrentRow().setAttribute("CExtAttr16","COMPLETE");
              //This assignment is to avoid future validation happen for non ebill method
              dlyMtd="eTXT";
            }
         }
        //For all record(other than complete, Non eBill document, set status to complete
        if ( dlyMtd.equals("eTXT") || dlyMtd.equals("eXLS") || dlyMtd.equals("ePDF"))
        {
          //Validation for eBill Releated customer Document.
          utl.log("validateCustDoc: eBilling Related doc. No Validation");
          CustDocVO.getCurrentRow().setAttribute("Ebilldet","Y");
        }////dlyMtd check 
        else//Non EBill Delivery method
        {
          CustDocVO.getCurrentRow().setAttribute("DExtAttr1",reqStDate);
          CustDocVO.getCurrentRow().setAttribute("DExtAttr2",reqEnDate);
          if (status.equals("IN_PROCESS") && payDocInd.equals("N") && !freq.equals("DAILY"))
          {
             if(!payTerm.equals(payDocPayTerm))
                throw new OAException("XXCRM","XXOD_EBL_INVALID_FREQUENCY");
          }          
          if (payDocInd.equals("Y"))
          {
            Serializable inputParams4[] = {  custDocId.toString(), custAcctId.toString() };
            am.invokeMethod("processPayDoc", inputParams4); 
          }
          utl.log("validateCustDoc: Setting Doc Status to Complete");
          utl.log("Req Start Date:"+reqStDate.toString());
          CustDocVO.getCurrentRow().setAttribute("CExtAttr16","COMPLETE");
          //CustDocVO.getCurrentRow().setAttribute("Readonlyflag",Boolean.TRUE);
        }//dlyMtd check else

      }//Added insted of Continue. else part of Status=COMPLETE
      //Data Capture & Validation for Pay doc group validation Begin
      String curSts=(String)CustDocVO.getCurrentRow().getAttribute("CExtAttr16");
      utl.log("Current Row Status :"+curSts+"Pay Doc Ind"+payDocInd);
      if(curSts.equals("COMPLETE") && payDocInd.equals("Y"))
      {
        Date enDate = (Date)CustDocVO.getCurrentRow().getAttribute("DExtAttr2");
        Date stDate = (Date)CustDocVO.getCurrentRow().getAttribute("DExtAttr1");
        Date curDate = (Date)Date.getCurrentDate();
        String combo = (String)CustDocVO.getCurrentRow().getAttribute("CExtAttr13");
        if(stDate==null)
        {
          throw new OAException("XXCRM","XXOD_EBL_PAYDOC_DATE_NULL");
        }
        
        if(stDate.compareTo(curDate)<=0 &&
        (enDate==null || curDate.compareTo(enDate)>=0))
        {
          utl.log("validateCustDoc: Valid Pay doc "+custDocId.toString());
              
          lnPayDocCnt=lnPayDocCnt+1;
          if(combo!=null && combo.equals("DB"))
            lnDrCnt = lnDrCnt +1;
          else if(combo!=null && combo.equals("CR"))
            lnCrCnt = lnCrCnt+1;

          if (enDate==null) lnEndDtNull=1; else lnEndDtNull=0;
        }

        if( stDate.compareTo(curDate)>0 && enDate==null )
        {
          utl.log("validateCustDoc: Valid Future Pay doc "+custDocId.toString());
              
          lnPayDocFCnt=lnPayDocFCnt+1;
          if(combo!=null && combo.equals("DB"))
            lnDrFCnt = lnDrFCnt +1;
          else if(combo!=null && combo.equals("CR"))
            lnCrFCnt = lnCrFCnt+1;
        }
            
      }
      //Data Capture & Validation for Pay doc group validation End
      CustDocVO.previous();
    }//For loop
    utl.log("validateCustDoc:Paydoc "+lnPayDocCnt+" dr "+lnDrCnt+" cr "+lnCrCnt);
    utl.log("validateCustDoc:PaydocF "+lnPayDocFCnt+" dr "+lnDrFCnt+" cr "+lnCrFCnt);
    //if(lnPayDocFCnt==2 && lnDrFCnt==0 && lnCrFCnt==0)
    //else 
    /*
    if (lnPayDocFCnt>1 && ((lnDrFCnt==0 || lnCrFCnt==0)))
    {
      throw new OAException("XXCRM","XXOD_EBL_PAYDOC_ADD_ERR");
    }
    else if (lnPayDocFCnt==2 && (lnDrFCnt!=1 || lnCrFCnt!=1) )
    {
      throw new OAException("XXCRM","XXOD_EBL_PAYDOC_COMBO_EXC");
    }else if (lnPayDocFCnt==1 && (lnDrFCnt==1 || lnCrFCnt==1))
    {
      throw new OAException("XXCRM","XXOD_EBL_PAYDOC_COMBO_EXC");
    }else if (lnPayDocFCnt>2 && ((lnDrFCnt>0 || lnCrFCnt>0)))
    {
      throw new OAException("XXCRM","XXOD_EBL_PAYDOC_ADD_ERR");
    }
    */
    //Active pay doc end date is NULL and new future pay doc with end date null is created
    if(lnEndDtNull==1 && lnPayDocFCnt>0 && lnPayDocCnt>0)
    {
      throw new OAException("XXCRM","XXOD_EBL_INVALID_PAYDOC_DATES");
    }
  
   }//validateCustDoc method

   public String getFormattedDate(Date dt)
   {
     String DATE_FORMAT_NOW = "dd-MM-yyyy";
     //DATE lDt=(DATE)dt;
     //Calendar cal = Calendar.getInstance();
     SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
     return sdf.format(dt);

   }//End getFormattedDate()

   public void gotoPage(int pRecNr,OAViewObject CustDocVO)
   {
        int lCnt = CustDocVO.getRowCount();
        if (lCnt<=10 || pRecNr==0)
          return;
        CustDocVO.last();
        for(int i=1;i<lCnt-pRecNr;i++)
          CustDocVO.previous();       
   }


}
